package com.karaoke_management.service.impl;

import com.karaoke_management.entity.Invoice;
import com.karaoke_management.entity.Shift;
import com.karaoke_management.enums.InvoiceStatus;
import com.karaoke_management.enums.ShiftStatus;
import com.karaoke_management.repository.InvoiceRepository;
import com.karaoke_management.repository.ShiftRepository;
import com.karaoke_management.service.ShiftService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ShiftServiceImpl implements ShiftService {

    private final ShiftRepository shiftRepository;
    private final InvoiceRepository invoiceRepository;

    @Override
    public Optional<Shift> getCurrentOpenShift() {
        return shiftRepository.findFirstByStatusOrderByOpenedAtDesc(ShiftStatus.OPEN);
    }

    @Override
    @Transactional
    public Shift openShift(BigDecimal openingCash, String openedBy) {
        if (openingCash == null) openingCash = BigDecimal.ZERO;

        Optional<Shift> current = getCurrentOpenShift();
        if (current.isPresent()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Đang có ca mở, không thể mở ca mới");
        }

        Shift s = new Shift();
        s.setStatus(ShiftStatus.OPEN);
        s.setOpenedAt(LocalDateTime.now());
        s.setOpenedBy(openedBy);
        s.setOpeningCash(openingCash);

        // init số liệu
        s.setTotalInvoices(0);
        s.setTotalRevenue(BigDecimal.ZERO);
        s.setTotalCash(BigDecimal.ZERO);
        s.setTotalVnpay(BigDecimal.ZERO);
        s.setTotalOther(BigDecimal.ZERO);
        s.setRoomRevenue(BigDecimal.ZERO);
        s.setOrderRevenue(BigDecimal.ZERO);

        return shiftRepository.save(s);
    }

    @Override
    @Transactional
    public Shift closeShift(Long shiftId, BigDecimal closingCash, String closedBy) {
        Shift s = getById(shiftId);

        if (s.getStatus() != ShiftStatus.OPEN) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ca đã đóng hoặc không hợp lệ");
        }

        if (closingCash == null) closingCash = BigDecimal.ZERO;

        LocalDateTime from = s.getOpenedAt();
        LocalDateTime to = LocalDateTime.now();

        // Lấy hóa đơn đã thanh toán trong ca
        // Bạn cần có method repo phù hợp (xem note dưới)
        List<Invoice> paidInvoices = invoiceRepository
                .findAllByStatusAndPaidAtBetweenOrderByPaidAtAsc(InvoiceStatus.PAID, from, to);

        BigDecimal totalRevenue = BigDecimal.ZERO;
        BigDecimal totalCash = BigDecimal.ZERO;
        BigDecimal totalVnpay = BigDecimal.ZERO;
        BigDecimal totalOther = BigDecimal.ZERO;

        for (Invoice inv : paidInvoices) {
            BigDecimal amount = inv.getTotalAmount() != null ? inv.getTotalAmount() : BigDecimal.ZERO;
            totalRevenue = totalRevenue.add(amount);

            String method = inv.getPaymentMethod() != null ? inv.getPaymentMethod() : "UNKNOWN";
            if ("CASH".equalsIgnoreCase(method)) totalCash = totalCash.add(amount);
            else if ("VNPAY".equalsIgnoreCase(method)) totalVnpay = totalVnpay.add(amount);
            else totalOther = totalOther.add(amount);
        }

        s.setClosedAt(to);
        s.setClosedBy(closedBy);
        s.setClosingCash(closingCash);

        s.setTotalInvoices(paidInvoices.size());
        s.setTotalRevenue(totalRevenue);
        s.setTotalCash(totalCash);
        s.setTotalVnpay(totalVnpay);
        s.setTotalOther(totalOther);

        // Chênh lệch tiền mặt: (closing - opening - cashRevenue)
        BigDecimal openingCash = s.getOpeningCash() != null ? s.getOpeningCash() : BigDecimal.ZERO;
        BigDecimal diff = closingCash.subtract(openingCash).subtract(totalCash);
        s.setCashDiff(diff);

        s.setStatus(ShiftStatus.CLOSED);

        return shiftRepository.save(s);
    }

    @Override
    public Shift getById(Long shiftId) {
        return shiftRepository.findById(shiftId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Không tìm thấy ca"));
    }
}