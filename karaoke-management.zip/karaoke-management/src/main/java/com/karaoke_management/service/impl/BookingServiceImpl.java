package com.karaoke_management.service.impl;

import com.karaoke_management.entity.Booking;
import com.karaoke_management.entity.BookingStatus;
import com.karaoke_management.repository.BookingRepository;
import com.karaoke_management.service.BookingService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;

    @PersistenceContext
    private EntityManager em;

    public BookingServiceImpl(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Booking> findAll() {
        return bookingRepository.findAll();
    }

    @Override
    public Booking save(Booking booking) {
        return bookingRepository.save(booking);
    }

    @Override
    @Transactional(readOnly = true)
    public Booking findById(Long id) {
        return bookingRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteById(Long id) {
        bookingRepository.deleteById(id);
    }

    /**
     * Check trùng giờ đặt phòng:
     * Overlap nếu: startTime < existing.endTime AND endTime > existing.startTime
     * excludeBookingId: dùng khi update (loại trừ chính booking đang sửa), tạo mới thì null.
     */
    @Override
    @Transactional(readOnly = true)
    public boolean hasBookingConflict(Long roomId,
                                      LocalDateTime startTime,
                                      LocalDateTime endTime,
                                      Long excludeBookingId) {

        if (roomId == null || startTime == null || endTime == null) return false;

        // thời gian không hợp lệ thì coi như conflict để chặn
        if (!startTime.isBefore(endTime)) return true;

        // Chống trùng chuẩn: bỏ qua booking đã hủy (CANCELLED)
        // Dùng query chuẩn overlap: newStart < oldEnd AND newEnd > oldStart
        return bookingRepository.existsOverlapExcludingStatus(
            roomId,
            excludeBookingId,
            startTime,
            endTime,
            BookingStatus.CANCELLED
        );
    }
}
