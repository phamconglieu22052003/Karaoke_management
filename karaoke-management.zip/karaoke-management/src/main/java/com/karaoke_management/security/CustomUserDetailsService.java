package com.karaoke_management.security;

public class CustomUserDetailsService {
    
}
