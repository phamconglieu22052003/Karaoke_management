package com.karaoke_management.dto;

import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

public class BookingDTO {

    private Long id;

    private Long roomId;

    @DateTimeFormat(pattern = "HH:mm dd/MM/yyyy")
    private LocalDateTime startTime;

    @DateTimeFormat(pattern = "HH:mm dd/MM/yyyy")
    private LocalDateTime endTime;

    private String customerName;

    private String phone;

    // ===== Getter / Setter =====
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
