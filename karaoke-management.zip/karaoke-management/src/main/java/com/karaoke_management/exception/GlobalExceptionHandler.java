package com.karaoke_management.exception;

public class GlobalExceptionHandler {
    
}
