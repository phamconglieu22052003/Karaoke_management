package com.karaoke_management.entity;

public enum RoomStatus {
    AVAILABLE,   // phòng trống
    OCCUPIED,    // đang sử dụng (đã check-in)
    MAINTENANCE  // bảo trì (tuỳ chọn)
}
