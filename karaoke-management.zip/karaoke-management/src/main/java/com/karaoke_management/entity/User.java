package com.karaoke_management.entity;

public class User {
    
}
