package com.karaoke_management.entity;

public enum InvoiceStatus {
    UNPAID,
    PAID,
    FAILED
}
