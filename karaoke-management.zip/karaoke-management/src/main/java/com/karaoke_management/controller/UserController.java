package com.karaoke_management.controller;

public class UserController {
    
}
