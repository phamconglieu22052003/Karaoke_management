package com.karaoke_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KaraokeManagementApplication {
  public static void main(String[] args) {
    SpringApplication.run(KaraokeManagementApplication.class, args);
  }
}
