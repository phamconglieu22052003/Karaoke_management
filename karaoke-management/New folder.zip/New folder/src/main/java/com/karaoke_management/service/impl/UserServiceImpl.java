package com.karaoke_management.service.impl;

public class UserServiceImpl {
    
}
