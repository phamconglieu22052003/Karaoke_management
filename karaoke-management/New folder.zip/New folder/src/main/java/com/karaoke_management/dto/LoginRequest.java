package com.karaoke_management.dto;

public class LoginRequest {
    
}
