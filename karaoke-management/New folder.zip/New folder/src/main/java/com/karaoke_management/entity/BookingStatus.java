package com.karaoke_management.entity;

public enum BookingStatus {
    BOOKED,
    CONFIRMED,
    CANCELLED
}
