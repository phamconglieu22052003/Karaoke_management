package com.karaoke_management.repository;

public class UserRepository {
    
}
