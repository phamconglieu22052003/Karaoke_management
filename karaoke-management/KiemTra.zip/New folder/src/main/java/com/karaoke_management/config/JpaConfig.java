package com.karaoke_management.config;

public class JpaConfig {
    
}
