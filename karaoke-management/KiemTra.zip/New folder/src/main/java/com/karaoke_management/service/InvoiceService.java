package com.karaoke_management.service;

public class InvoiceService {
    
}
