package com.karaoke_management.controller;

public class InvoiceController {
    
}
