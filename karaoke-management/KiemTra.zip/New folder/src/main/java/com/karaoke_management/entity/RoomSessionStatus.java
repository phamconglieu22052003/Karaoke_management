package com.karaoke_management.entity;

public enum RoomSessionStatus {
    ACTIVE,
    CLOSED
}
